# Environment Configuration for grepme-x with OpenRouter Integration

## OpenRouter API Setup

1. **Get your OpenRouter API Key:**
   - Go to https://openrouter.ai
   - Sign up or log in to your account
   - Navigate to the API keys section
   - Create a new API key

2. **Set environment variables:**
   ```bash
   # Copy .env.example to .env
   cp .env.example .env
   
   # Edit .env and add your actual API key
   OPENROUTER_API_KEY=your_actual_api_key_here
   ```

3. **Optional Configuration:**
   - `OPENROUTER_MODEL`: Model to use (default: gpt-3.5-turbo)
   - `ENABLE_AI_DESCRIPTIONS`: Set to false to disable AI descriptions (default: true)

## Models Available on OpenRouter

Popular models you can use:
- `gpt-3.5-turbo` (Fast, cost-effective)
- `gpt-4` (Higher quality)
- `gpt-4-turbo-preview` (Latest GPT-4)
- `openai/gpt-3.5-turbo` (With OpenRouter branding)
- `anthropic/claude-3-sonnet` (Anthropic Claude)

Update the `OPENROUTER_MODEL` in your .env file to use a different model.

## Usage

Run grepme-x with AI-powered controller descriptions:

```bash
npm run grepme-x
# or
node index.js
```

The tool will:
1. Analyze your codebase
2. Extract controllers and functions
3. Generate AI descriptions for each controller using OpenRouter API
4. Create a Copilot-style README with descriptions

## Example Output

When AI descriptions are enabled, the Controllers section will look like:

```markdown
## Controllers

- **`getFiles`** — Recursively scans directory tree, ignoring node_modules and binary files
- **`safeRead`** — Safely reads file content with error handling, returns empty string on failure
- **`buildTree`** — Generates ASCII file tree representation with proper indentation and connectors
```

## Troubleshooting

- **No API key error?** → Make sure you've added OPENROUTER_API_KEY to your .env file
- **Rate limiting?** → The tool adds 500ms delays between requests to avoid hitting rate limits
- **Want to skip AI?** → Set `ENABLE_AI_DESCRIPTIONS=false` in .env or remove the key
- **Check costs?** → Monitor your OpenRouter dashboard to see token usage and costs

## Security Note

- Never commit your `.env` file to git
- The `.gitignore` file already excludes `.env`
- Keep your API key private and rotate if exposed
